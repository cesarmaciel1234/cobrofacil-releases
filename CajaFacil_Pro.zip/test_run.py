import sys
from PyQt5.QtWidgets import QApplication
from src.paso2_perfil import Paso2Perfil

app = QApplication(sys.argv)
print("Antes de exec")
dlg = Paso2Perfil()
res = dlg.exec_()
print("Despues de exec, res=", res)
