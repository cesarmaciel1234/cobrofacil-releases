import sys
from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow
from PyQt5.QtCore import QTimer

app = QApplication(sys.argv)
app.setQuitOnLastWindowClosed(False)

d = QDialog()
QTimer.singleShot(500, d.accept)
res = d.exec_()
print("Dialog finished", res)

w = QMainWindow()
w.show()

app.setQuitOnLastWindowClosed(True)
print("Before app.exec")
QTimer.singleShot(1000, app.quit)
sys.exit(app.exec_())
